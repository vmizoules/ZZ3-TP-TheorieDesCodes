# Barret Alexandre - Mizoules Vincent
# Compte rendu - TP1

## Usage

Pour lancer notre programme et afficher le graph résultant, on utilise les commandes suivantes :

	make run
	okular graph.eps

Pour nettoyer le projet

	make clean
	make clear

## Réponses aux questions

### 1

Pour utiliser les fréquences par défaut, décommenter la ligne 351 et commentez la ligne 353.

### 2

Fait lors du `make run`

### 3

Fait par défaut (ligne 351 commentée et 353 décommentée).

### 4

La longueur moyenne des codes de Huffman est affichée lors de l'exécution.

### 5

Le taux de compression est affiché lors de l'exécution du programme.


